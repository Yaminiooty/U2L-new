#!/usr/bin/perl

use Encode::Guess qw/euc-jp shiftjis 7bit-jis utf8/;

if ($#ARGV < 2){
	die "Usage: kanjichecker.pl [euc|sjis|jis|utf8] dir path_to_file\n";
}

$current	= $ARGV[0] || $current_default;
$dir		= $ARGV[1];
$file		= $ARGV[2];

#print "$current $dir $file\n";
# if file was removed already, check isn't need.
unless (-f $file) {
	exit 0;
}

open(my $fh, "<$file") || die("Can't open $file");

my $encname;
my $code = 0;
while(<$fh>) {
	my $enc = guess_encoding($_);
	if ( ref($enc) ) {
		$encname = $enc->name;
	}
	else {
		# if : can't recognize by guess_encoding(), use code of before character.
		if ( $code == 1 && $enc =~ /euc-jp/ ) {
			$encname = "euc-jp";
		}
		elsif ( $code == 2 && $enc =~ /shiftjis/ ) {
			$encname = "shiftjis";
		}
		elsif ( $code == 4 && $enc =~ /7bit-jis/ ) {
			$encname = "7bit-jis";
		}
		elsif ( $code == 8 && $enc =~ /utf8/ ) {
			$encname = "utf8";
		}
		else {
			$encname = "$enc";
		}
	}
	if ( $encname =~ /euc-jp/ ) {
		$code |= 1;
	}
	if ( $encname =~ /shiftjis/ ) {
		$code |= 2;
	}
	if ( $encname =~ /7bit-jis/ ) {
		$code |= 4;
	}
	if ( $encname =~ /utf8/ ) {
		$code |= 8;
	}
#	print "$encname $code\n";
}
close($fh);

#print "$current $code\n";
if ( $code == 0 ) {
	exit 0;
}
elsif ( $current eq 'euc' && $code == 1 ) {
	exit 0;
}
elsif ( $current eq 'sjis' && $code == 2 ) {
	exit 0;
}
elsif ( $current eq 'jis' && $code == 4 ) {
	exit 0;
}
elsif ( $current eq 'utf8' &&  $code == 8 ) {
	exit 0;
}
else {
	die "$file : current code is not $current.\n";
}

exit 0;
